CREATE EXTENSION postgis;

CREATE TABLE IF NOT EXISTS locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    geom GEOGRAPHY(POINT, 4326)
);

CREATE TABLE IF NOT EXISTS routes (
    id SERIAL PRIMARY KEY,
    start_location_id INT REFERENCES locations(id),
    end_location_id INT REFERENCES locations(id),
    distance FLOAT,
    duration FLOAT
);

CREATE TABLE IF NOT EXISTS vehicles (
    id SERIAL PRIMARY KEY,
    vehicle_number VARCHAR(50) NOT NULL,
    current_location_id INT REFERENCES locations(id),
    status VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS schedules (
    id SERIAL PRIMARY KEY,
    vehicle_id INT REFERENCES vehicles(id),
    route_id INT REFERENCES routes(id),
    scheduled_time TIMESTAMP,
    status VARCHAR(50) NOT NULL
);