import { Router } from 'express';
import TrackingController from '../controllers/trackingController';
import DispatchController from '../controllers/dispatchController';
import ReportController from '../controllers/reportController';

const router = Router();

const trackingController = new TrackingController();
const dispatchController = new DispatchController();
const reportController = new ReportController();

// Tracking routes
router.get('/tracking', trackingController.getRealTimeTracking);
router.get('/tracking/:vehicleId', trackingController.getTrackingByVehicleId);

// Dispatch routes
router.post('/dispatch', dispatchController.createDispatchPlan);
router.put('/dispatch/:id', dispatchController.updateDispatchPlan);
router.get('/dispatch', dispatchController.getAllDispatchPlans);

// Report routes
router.get('/reports', reportController.getReports);
router.get('/reports/:id', reportController.getReportById);

export default router;