import express from 'express';
import mongoose from 'mongoose';
import config from './config';
import routes from './routes';
import { Logger } from './utils/logger';

const app = express();
const logger = new Logger();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api', routes);

// Database connection
mongoose.connect(config.databaseUrl, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        logger.info('Database connected successfully');
        const PORT = config.port || 3000;
        app.listen(PORT, () => {
            logger.info(`Server is running on port ${PORT}`);
        });
    })
    .catch(err => {
        logger.error('Database connection error:', err);
    });