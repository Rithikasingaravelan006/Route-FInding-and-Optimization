export class NotificationService {
    sendDelayNotification(vehicleId: string, delayReason: string): void {
        // Logic to send notification about delay
        console.log(`Notification: Vehicle ${vehicleId} is delayed due to ${delayReason}.`);
    }

    sendDetourNotification(vehicleId: string, detourReason: string): void {
        // Logic to send notification about detour
        console.log(`Notification: Vehicle ${vehicleId} has taken a detour due to ${detourReason}.`);
    }

    sendScheduleUpdateNotification(vehicleId: string, newSchedule: any): void {
        // Logic to send notification about schedule updates
        console.log(`Notification: Vehicle ${vehicleId} schedule updated. New schedule: ${JSON.stringify(newSchedule)}`);
    }
}