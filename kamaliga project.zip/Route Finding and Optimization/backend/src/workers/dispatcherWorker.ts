import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
import { DispatchService } from '../services/dispatchService';
import { NotificationService } from '../services/notificationService';

if (isMainThread) {
    // This file is intended to be run as a worker thread.
    throw new Error('This file should be run as a worker thread.');
}

const dispatchService = new DispatchService();
const notificationService = new NotificationService();

async function processDispatchUpdates() {
    try {
        const updates = await dispatchService.getPendingUpdates();
        for (const update of updates) {
            await dispatchService.processUpdate(update);
            await notificationService.sendUpdateNotification(update);
        }
    } catch (error) {
        console.error('Error processing dispatch updates:', error);
    }
}

processDispatchUpdates();