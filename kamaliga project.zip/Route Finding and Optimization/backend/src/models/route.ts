export interface Route {
    id: string;
    startLocation: {
        latitude: number;
        longitude: number;
    };
    endLocation: {
        latitude: number;
        longitude: number;
    };
    waypoints?: Array<{
        latitude: number;
        longitude: number;
    }>;
    distance: number; // in kilometers
    estimatedTime: number; // in minutes
    status: 'pending' | 'in-progress' | 'completed' | 'delayed';
    createdAt: Date;
    updatedAt: Date;
}