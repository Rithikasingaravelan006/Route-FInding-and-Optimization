export interface Telemetry {
    vehicleId: string;
    timestamp: Date;
    latitude: number;
    longitude: number;
    speed: number;
    fuelLevel: number;
    status: string; // e.g., "on route", "delayed", "completed"
}

export class TelemetryModel {
    private telemetryData: Telemetry[] = [];

    public addTelemetry(data: Telemetry): void {
        this.telemetryData.push(data);
    }

    public getLatestTelemetry(vehicleId: string): Telemetry | null {
        const vehicleTelemetry = this.telemetryData.filter(t => t.vehicleId === vehicleId);
        return vehicleTelemetry.length > 0 ? vehicleTelemetry[vehicleTelemetry.length - 1] : null;
    }

    public getAllTelemetry(): Telemetry[] {
        return this.telemetryData;
    }
}