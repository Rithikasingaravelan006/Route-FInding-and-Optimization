export interface Vehicle {
    id: string;
    licensePlate: string;
    model: string;
    capacity: number; // in kilograms
    currentLocation: {
        latitude: number;
        longitude: number;
    };
    status: 'active' | 'inactive' | 'in_maintenance';
    lastUpdated: Date;
}