import { Schema, model } from 'mongoose';

const scheduleSchema = new Schema({
    vehicleId: {
        type: String,
        required: true,
    },
    routeId: {
        type: String,
        required: true,
    },
    departureTime: {
        type: Date,
        required: true,
    },
    estimatedArrivalTime: {
        type: Date,
        required: true,
    },
    status: {
        type: String,
        enum: ['on-time', 'delayed', 'completed'],
        default: 'on-time',
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
});

scheduleSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

export const Schedule = model('Schedule', scheduleSchema);