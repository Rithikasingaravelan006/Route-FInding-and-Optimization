class TrackingController {
    constructor(private gpsService: GPSService, private geofenceService: GeofenceService, private notificationService: NotificationService) {}

    public trackVehicle(req: Request, res: Response): void {
        const vehicleId = req.params.id;
        this.gpsService.getCurrentLocation(vehicleId)
            .then(location => {
                res.status(200).json({ location });
            })
            .catch(error => {
                res.status(500).json({ error: 'Error tracking vehicle' });
            });
    }

    public getGeofencedAlerts(req: Request, res: Response): void {
        const vehicleId = req.params.id;
        this.geofenceService.getAlertsForVehicle(vehicleId)
            .then(alerts => {
                res.status(200).json({ alerts });
            })
            .catch(error => {
                res.status(500).json({ error: 'Error retrieving geofenced alerts' });
            });
    }

    public updateDispatchPlan(req: Request, res: Response): void {
        const { vehicleId, newPlan } = req.body;
        this.gpsService.updateDispatchPlan(vehicleId, newPlan)
            .then(() => {
                res.status(200).json({ message: 'Dispatch plan updated successfully' });
            })
            .catch(error => {
                res.status(500).json({ error: 'Error updating dispatch plan' });
            });
    }

    public captureLiveData(req: Request, res: Response): void {
        const vehicleId = req.params.id;
        this.gpsService.captureLiveData(vehicleId)
            .then(data => {
                res.status(200).json({ data });
            })
            .catch(error => {
                res.status(500).json({ error: 'Error capturing live data' });
            });
    }
}

export default TrackingController;