# API Documentation for Route Finding and Optimization

## Overview
The Route Finding and Optimization project provides a GPS and GIS-based system for the Department of Posts. This API enables real-time truck tracking, geofenced alerts for delays or detours, and dynamic schedule management.

## Base URL
The base URL for all API endpoints is:
```
http://<your-server-address>/api
```

## Authentication
All endpoints require authentication. Use the following method to authenticate:
- **Token-based authentication**: Include the token in the `Authorization` header as `Bearer <token>`.

## Endpoints

### 1. Tracking

#### GET /tracking
- **Description**: Retrieve real-time tracking information for all vehicles.
- **Response**: 
  - 200 OK: Returns an array of tracking data for each vehicle.
  - 401 Unauthorized: If authentication fails.

#### GET /tracking/:vehicleId
- **Description**: Retrieve tracking information for a specific vehicle.
- **Parameters**: 
  - `vehicleId`: The ID of the vehicle to track.
- **Response**: 
  - 200 OK: Returns tracking data for the specified vehicle.
  - 404 Not Found: If the vehicle does not exist.
  - 401 Unauthorized: If authentication fails.

### 2. Dispatch

#### POST /dispatch
- **Description**: Create a new dispatch plan.
- **Body**: 
  - `vehicleId`: ID of the vehicle.
  - `routeId`: ID of the route.
  - `schedule`: Dispatch schedule details.
- **Response**: 
  - 201 Created: Returns the created dispatch plan.
  - 400 Bad Request: If the input data is invalid.
  - 401 Unauthorized: If authentication fails.

#### GET /dispatch/:dispatchId
- **Description**: Retrieve details of a specific dispatch plan.
- **Parameters**: 
  - `dispatchId`: The ID of the dispatch plan.
- **Response**: 
  - 200 OK: Returns the dispatch plan details.
  - 404 Not Found: If the dispatch plan does not exist.
  - 401 Unauthorized: If authentication fails.

### 3. Reports

#### GET /reports
- **Description**: Generate and retrieve visual MIS reports.
- **Response**: 
  - 200 OK: Returns an array of report data.
  - 401 Unauthorized: If authentication fails.

#### GET /reports/:reportId
- **Description**: Retrieve a specific MIS report.
- **Parameters**: 
  - `reportId`: The ID of the report.
- **Response**: 
  - 200 OK: Returns the specified report.
  - 404 Not Found: If the report does not exist.
  - 401 Unauthorized: If authentication fails.

### 4. Notifications

#### POST /notifications
- **Description**: Send notifications related to delays or detours.
- **Body**: 
  - `message`: The notification message.
  - `vehicleId`: ID of the vehicle associated with the notification.
- **Response**: 
  - 201 Created: Returns the created notification.
  - 400 Bad Request: If the input data is invalid.
  - 401 Unauthorized: If authentication fails.

## Error Handling
All responses will include an error message in the following format:
```json
{
  "error": {
    "code": "error_code",
    "message": "Detailed error message"
  }
}
```

## Conclusion
This API documentation provides a comprehensive overview of the available endpoints for the Route Finding and Optimization project. For further details, please refer to the individual endpoint descriptions.