export type Vehicle = {
    id: string;
    licensePlate: string;
    model: string;
    currentLocation: {
        latitude: number;
        longitude: number;
    };
    status: 'active' | 'inactive' | 'inMaintenance';
};

export type Route = {
    id: string;
    startLocation: {
        latitude: number;
        longitude: number;
    };
    endLocation: {
        latitude: number;
        longitude: number;
    };
    waypoints: Array<{
        latitude: number;
        longitude: number;
    }>;
    estimatedTime: number; // in minutes
};

export type Schedule = {
    id: string;
    vehicleId: string;
    routeId: string;
    departureTime: Date;
    arrivalTime: Date;
    status: 'scheduled' | 'inProgress' | 'completed' | 'delayed';
};

export type Telemetry = {
    vehicleId: string;
    timestamp: Date;
    speed: number; // in km/h
    fuelLevel: number; // in percentage
    location: {
        latitude: number;
        longitude: number;
    };
};