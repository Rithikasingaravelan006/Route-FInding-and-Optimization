export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const toRad = (value: number) => (value * Math.PI) / 180;
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in kilometers
};

export const isPointInPolygon = (point: { lat: number; lon: number }, polygon: Array<{ lat: number; lon: number }>): boolean => {
    let inside = false;
    const { lat, lon } = point;
    const n = polygon.length;

    for (let i = 0, j = n - 1; i < n; j = i++) {
        const xi = polygon[i].lon, yi = polygon[i].lat;
        const xj = polygon[j].lon, yj = polygon[j].lat;

        const intersect = ((yi > lat) !== (yj > lat)) &&
                          (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }

    return inside;
};

export const getGeofenceAlerts = (vehicleLocation: { lat: number; lon: number }, geofences: Array<Array<{ lat: number; lon: number }>>): Array<string> => {
    const alerts: Array<string> = [];
    geofences.forEach((geofence, index) => {
        if (isPointInPolygon(vehicleLocation, geofence)) {
            alerts.push(`Vehicle is within geofence ${index + 1}`);
        }
    });
    return alerts;
};