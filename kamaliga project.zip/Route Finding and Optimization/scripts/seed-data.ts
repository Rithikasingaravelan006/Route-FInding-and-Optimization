import { Vehicle } from '../backend/src/models/vehicle';
import { Route } from '../backend/src/models/route';
import { Schedule } from '../backend/src/models/schedule';
import { Telemetry } from '../backend/src/models/telemetry';

const seedVehicles = async () => {
    const vehicles = [
        { id: 1, name: 'Truck A', capacity: 1000 },
        { id: 2, name: 'Truck B', capacity: 1500 },
        { id: 3, name: 'Truck C', capacity: 1200 },
    ];
    await Vehicle.insertMany(vehicles);
};

const seedRoutes = async () => {
    const routes = [
        { id: 1, name: 'Route 1', distance: 50 },
        { id: 2, name: 'Route 2', distance: 75 },
        { id: 3, name: 'Route 3', distance: 100 },
    ];
    await Route.insertMany(routes);
};

const seedSchedules = async () => {
    const schedules = [
        { id: 1, vehicleId: 1, routeId: 1, departureTime: new Date(), arrivalTime: new Date(Date.now() + 3600000) },
        { id: 2, vehicleId: 2, routeId: 2, departureTime: new Date(), arrivalTime: new Date(Date.now() + 7200000) },
        { id: 3, vehicleId: 3, routeId: 3, departureTime: new Date(), arrivalTime: new Date(Date.now() + 10800000) },
    ];
    await Schedule.insertMany(schedules);
};

const seedTelemetry = async () => {
    const telemetryData = [
        { vehicleId: 1, location: { lat: 12.9716, lng: 77.5946 }, speed: 60 },
        { vehicleId: 2, location: { lat: 13.0827, lng: 80.2707 }, speed: 50 },
        { vehicleId: 3, location: { lat: 28.6139, lng: 77.2090 }, speed: 70 },
    ];
    await Telemetry.insertMany(telemetryData);
};

const seedData = async () => {
    await seedVehicles();
    await seedRoutes();
    await seedSchedules();
    await seedTelemetry();
    console.log('Database seeded successfully!');
};

seedData().catch(err => {
    console.error('Error seeding data:', err);
});