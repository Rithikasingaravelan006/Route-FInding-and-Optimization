#!/bin/bash

# Navigate to the backend directory and build the backend application
cd backend
npm install
npm run build

# Navigate to the frontend directory and build the frontend application
cd ../frontend
npm install
npm run build

# Navigate to the infra directory and start the application using Docker Compose
cd ../infra
docker-compose up -d

# Print deployment status
echo "Deployment completed successfully!"