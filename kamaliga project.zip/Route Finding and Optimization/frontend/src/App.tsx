import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Tracking from './pages/Tracking';
import Dispatch from './pages/Dispatch';
import Reports from './pages/Reports';
import Login from './pages/Login';
import Dashboard from './components/Dashboard';
import MISReports from './components/MISReports';

const App: React.FC = () => {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Login} />
        <Route path="/tracking" component={Tracking} />
        <Route path="/dispatch" component={Dispatch} />
        <Route path="/reports" component={Reports} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/mis-reports" component={MISReports} />
      </Switch>
    </Router>
  );
};

export default App;