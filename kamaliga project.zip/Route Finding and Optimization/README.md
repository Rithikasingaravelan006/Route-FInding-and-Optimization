# Route Finding and Optimization

## Project Overview
The "Route Finding and Optimization" project aims to develop a GPS and GIS-based system for the Department of Posts. This system will enable real-time truck tracking, geofenced alerts for delays or detours, and dynamic schedule management. The project focuses on ensuring timely parcel and mail delivery through efficient route management and live data capture.

## Features
- **Real-Time Truck Tracking**: Monitor the location of delivery trucks in real-time using GPS data.
- **Geofenced Alerts**: Receive notifications for delays or detours when trucks enter or exit predefined geofenced areas.
- **Dynamic Schedule Management**: Automatically update dispatch plans based on real-time data and changing conditions.
- **Live Data Capture**: Collect and process live telemetry data from vehicles to enhance decision-making.
- **Visual MIS Reports**: Generate and display Management Information System (MIS) reports for tracking performance and operational efficiency.

## Technology Stack
- **Backend**: Node.js, Express, TypeScript
- **Frontend**: React, TypeScript
- **Database**: PostgreSQL with PostGIS for geographic data handling
- **Deployment**: Docker, Docker Compose

## Directory Structure
```
Route Finding and Optimization
├── backend
├── frontend
├── shared
├── infra
├── scripts
├── tests
├── docs
├── .env.example
├── package.json
├── tsconfig.json
└── README.md
```

## Getting Started
1. **Clone the Repository**: 
   ```
   git clone <repository-url>
   cd "Route Finding and Optimization"
   ```

2. **Backend Setup**:
   - Navigate to the `backend` directory.
   - Install dependencies:
     ```
     npm install
     ```
   - Start the backend server:
     ```
     npm start
     ```

3. **Frontend Setup**:
   - Navigate to the `frontend` directory.
   - Install dependencies:
     ```
     npm install
     ```
   - Start the frontend application:
     ```
     npm start
     ```

4. **Database Setup**:
   - Ensure PostgreSQL is running.
   - Run the database migrations to set up the schema.

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for details.